import './clock';
import './carousel';

// Styles
import '../sass/main.scss';

// Images.
import '../img/cats.jpg';
import '../img/patterns/cover.jpg';
