var options = {
  strings: ["Texto1", "Texto2"],
  typeSpeed: 80,
  backSpeed: 80,
  loop: true,
};

var typed = new Typed("#texto-banner", options);
