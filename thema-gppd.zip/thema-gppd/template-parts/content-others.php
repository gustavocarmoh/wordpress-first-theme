<?php

?>
<article id="post-<?php the_ID(); ?>" <?php post_class('mb-5');?>>
    <?php
        get_template_part('template-parts/components/others/entry-header');
        #get_template_part('template-parts/components/blog/entry-meta');
        get_template_part('template-parts/components/others/entry-content');
        #get_template_part('template-parts/components/blog/entry-footer'); 
    ?>
</article>