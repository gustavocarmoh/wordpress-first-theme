<div class="entry-meta mb-3">
	<?php
	aquila_posted_by();
	aquila_posted_on();
	?>
</div>
